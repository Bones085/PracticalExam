﻿TW.Runtime.Widgets.OpenStreetMap = function () {
    "use strict";
    var thisWidget = this;
    var infoWindow = undefined;
	var userHasPannedOrZoomedSinceAutoZoom = false;
	var initialData = true;
	var weAreChangingBounds = false;
	var autoZoomBehavior = 'every-data-change';
    var regionInfoWindow = undefined;
    var lastRegionNumber = undefined;
    var lastData = undefined;
    var lastRegionData = undefined;
    var infoId = 'MapInfoWindow' + TW.uniqueId();
    var tooltipMashupWidth = 100;
    var tooltipMashupHeight = 100;
    var isMashupTooltipConfigured = false;
    var isRegionTooltipConfigured = false;
    var dataInfotable = undefined;
	var tileLayer = undefined;

 

    function autofitMap() {
		thisWidget.map.fitBounds(L.latLngBounds(thisWidget.getAllPoints()));
    }

    this.runtimeProperties = function () {
        return {
	        'supportsAutoResize': true,
            'needsDataLoadingAndError': true,
            'propertyAttributes': {
                'TooltipLabel1': {'isLocalizable': true},
                'TooltipLabel2': {'isLocalizable': true},
                'TooltipLabel3': {'isLocalizable': true},
                'TooltipLabel4': {'isLocalizable': true},
                'RegionTooltipLabel1': {'isLocalizable': true},
                'RegionTooltipLabel2': {'isLocalizable': true},
                'RegionTooltipLabel3': {'isLocalizable': true},
                'RegionTooltipLabel4': {'isLocalizable': true}
            }
        };
    };

    this.setSelectedMarker = function (selectedRow) {

        var isMultiselect = thisWidget.properties['MultiSelect'];

        var selMarker;

        for (var markerNo = 0; markerNo < thisWidget.currentMarkers.length; markerNo++) {
            var currentMarker = thisWidget.currentMarkers[markerNo];
            if (currentMarker.rowNumber === selectedRow) {
                selMarker = currentMarker;
                break;
            }
        }

        if (selMarker !== undefined) {
            if (selMarker._isSelected) {
                if (isMultiselect) {
                    TW.removeElementFromArray(thisWidget.selectedRows, selectedRow);
                    selMarker._isSelected = false;
                    selMarker.setIcon(selMarker._assignedIcon);
                    if (!thisWidget.ignoreSelectionEvent) {
                        thisWidget.updateSelection('Data', thisWidget.selectedRows);
                    }
                }
            }
            else {
                if (!isMultiselect) {
                    thisWidget.clearSelectedMarkers();
                    thisWidget.selectedRows = [selectedRow];
                }
                else
                    thisWidget.selectedRows.push(selectedRow);
				
				var iconImg = L.icon({
					iconUrl: thisWidget.selectedMarkerStyle.image,
					iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
				});
                selMarker.setIcon(iconImg);
				selMarker._isSelected = true;

                if (!thisWidget.ignoreSelectionEvent) {
                    thisWidget.updateSelection('Data', thisWidget.selectedRows);
                }
            }
        }
    };

    function handleMarkerMouseover (e) {
        var thisMarker = this;

        if (!isMashupTooltipConfigured) {
            return;
        }

        var selectedRowNo = thisMarker.rowNumber;

        TW.log.info('Should display info for Row #' + selectedRowNo);

        thisWidget.cleanupTooltipMashup();

        infoWindow.setContent('<div id="' + infoId + '" style="width:' + tooltipMashupWidth + 'px;height:' + tooltipMashupHeight + 'px;">Loading Tooltip Mashup...</div>');
        thisMarker.bindPopup(infoWindow).openPopup();

        setTimeout(function () {
            var mashupSpec = {};
            mashupSpec.mashupName = thisWidget.getProperty('TooltipMashupName');
            mashupSpec.mashupParameters = {};

            var mashupParameters = thisWidget.properties['MashupParameters'];
            if (mashupParameters === undefined)
                mashupParameters = [];

            var nParams = mashupParameters.length;

            for (var paramNo = 0; paramNo < nParams; paramNo++) {
                var paramInfo = mashupParameters[paramNo],
                    propName = paramInfo.ParameterName,
                    fldName = thisWidget.getProperty(propName),
                    propValue;
                if (fldName === 'ALL_FIELDS') {
                    propValue = JSON.parse(JSON.stringify(dataInfotable));
                    propValue.rows.push(lastData[selectedRowNo]);
                } else {
                    propValue = lastData[selectedRowNo][thisWidget.getProperty(propName)];
                }
                if (propValue !== undefined) {
                    mashupSpec.mashupParameters[propName] = propValue;
                }
            }

            $('#' + infoId).mashup(mashupSpec);
        }, 100);
    };

    function handleMarkerClick (e) {
        var thisMarker = this;
        thisWidget.setSelectedMarker(thisMarker.rowNumber);
    }

    function handleMarkerDoubleClick (e) {

        thisWidget.jqElement.triggerHandler('DoubleClicked');
    }

	this.resize = function(width,height) {
	};

    this.renderHtml = function () {

        tooltipMashupWidth = thisWidget.getProperty('TooltipMashupWidth');
        tooltipMashupHeight = thisWidget.getProperty('TooltipMashupHeight');
	    var oldAutoZoom = this.getProperty('AutoZoom');
	    autoZoomBehavior =  this.getProperty('AutoZoomBehavior');
	    switch( autoZoomBehavior ) {
		    case 'disable-on-user-pan-zoom':
		    case 'only-when-autozoom-invoked':
	        case 'only-initial-data':
			    // leave these alone
			    break;
		    default:
			    // anything else, default to our old behavior
			    if( oldAutoZoom === undefined || oldAutoZoom === true )  {
				    autoZoomBehavior = 'every-data-change';
			    } else if( oldAutoZoom === false ) {
				    autoZoomBehavior = 'only-when-autozoom-invoked';
			    } else {
				    autoZoomBehavior = 'every-data-change';
			    }
			    break;
	    }

        var mashupName = thisWidget.getProperty('TooltipMashupName');
        if (mashupName !== undefined && mashupName.length > 0) {
            isMashupTooltipConfigured = true;
        }

        try {
            //if (window.BMap !== undefined && window.BMap !== null) {
                this.haveOpenStreetMap = true;
            //}
        }
        catch (errmsg) {
        }

        if (this.haveOpenStreetMap)
		{
            return '<div class="widget-content widget-map-runtime"></div>';
		}
        else
            return '<div class="widget-content widget-map-runtime"><span class="textsize-large">Open Street Map is Not Available</span></div>';
    };

    this.haveOpenStreetMap = false;
    this.ignoreSelectionEvent = false;
    this.map = undefined;
    this.selectionMarker = null;
	this.selectedMarker = null;
    this.startMarker = null;
    this.endMarker = null;
	this.markerWidth = 0;
	this.markerHeight = 0;
    this.polyline = null;
    this.routePolyline = null;
    this.plannedRoutePolyline = null;
    this.dataBounds;
    this.plannedRouteDataBounds;
    this.routeDataBounds;
    this.regionDataBounds;
    this.lastBounds;
    this.lastZoom;
    this.markerLookup = new Array();
    this.currentMarkers = [];
    this.selectedRows = new Array();
    this.currentRegions = new Array();
    this.selectedRegionRows = new Array();
    this.markerStyle;
    this.selectedMarkerStyle;
    this.selectionMarkerStyle;
    this.startMarkerStyle;
    this.endMarkerStyle;
    this.pathStyle;
    this.routeStyle;
    this.plannedRouteStyle;
    this.regionStyle;
    this.positionData = [];
    this.routeData = [];
    this.plannedRouteData = [];
    this.regionData = [];
    this.regionLocationData = [];

    this.clearSelectedMarkers = function () {
        thisWidget.selectedRows = [];
        for (var markerNo = 0; markerNo < thisWidget.currentMarkers.length; markerNo++) {
            var currentMarker = thisWidget.currentMarkers[markerNo];
            currentMarker._isSelected = false;
            currentMarker.setIcon(currentMarker._assignedIcon);
        }
    };

    this.afterRender = function () {

        this.markerStyle = TW.getStyleFromStyleDefinition(this.getProperty('MarkerStyle'));
        this.selectionMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectionMarkerStyle'));
        this.selectedMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedMarkerStyle'));
        this.startMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('StartMarkerStyle'));
        this.endMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('EndMarkerStyle'));
		this.markerWidth = this.getProperty('MarkerWidth', 32);
		this.markerHeight = this.getProperty('MarkerHeight', 32);
        this.pathStyle = TW.getStyleFromStyleDefinition(this.getProperty('PathStyle'));
        this.plannedRouteStyle = TW.getStyleFromStyleDefinition(this.getProperty('PlannedRouteStyle'));
        this.routeStyle = TW.getStyleFromStyleDefinition(this.getProperty('RouteStyle'));
        this.regionStyle = TW.getStyleFromStyleDefinition(this.getProperty('RegionStyle'));
        this.selectedRegionStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedRegionStyle'));

		var zoom = parseInt(this.getProperty('Zoom'));
        
        var centerPosition = L.latLng(51.505, -0.09);

        if (this.getProperty('SelectedLocation') !== undefined) {
            centerPosition = L.latLng(this.getProperty('SelectedLocation').latitude, this.getProperty('SelectedLocation').longitude);
        }
			
        if (this.haveOpenStreetMap) {
            var map = this.map = L.map(thisWidget.jqElementId);
			map.setView(centerPosition, zoom);
			tileLayer = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png?{foo}', {foo: 'bar'});
			tileLayer.addTo(map);
			L.Util.requestAnimFrame(map.invalidateSize,map,!1,map._container);

			
            if (thisWidget.getProperty('EnableLocationSelection')) {
				function onMapDoubleClick(e) {
				
					var location = new Object();
                    location.units = "WGS84";
                    location.elevation = 0.0;
                    location.latitude = e.latlng.lat;
                    location.longitude = e.latlng.lng;

                    thisWidget.moveSelectionMarker(location);
                    thisWidget.setProperty('SelectedLocation', location);
                    thisWidget.jqElement.triggerHandler('Changed');
				}
				map.addEventListener('dblclick', onMapDoubleClick);
            } else {
                //map.enableDoubleClickZoom();
            }
			

            infoWindow = L.popup();
            regionInfoWindow = L.popup();
		
		
			if (thisWidget.getProperty('EnableMarkerSelection') === true) {
				var iconImg = L.icon({
					iconUrl: thisWidget.selectedMarkerStyle.image,
					iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
				});
                var selMarkerOpt = {
					icon: iconImg,
                    title: "Selected"
                };
                thisWidget.selectedMarker = L.marker(centerPosition, selMarkerOpt);
				thisWidget.selectedMarker.addTo(map);
			}
			
            if (thisWidget.getProperty('ShowSelectionMarker') === true) {
				var iconImg = L.icon({
					iconUrl: thisWidget.selectionMarkerStyle.image,
					iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
				});
                var selMarkerOpt = {
					icon: iconImg,
                    title: "Selected"
                };
                thisWidget.selectionMarker = L.marker(centerPosition, selMarkerOpt);
				thisWidget.selectionMarker.addTo(map);
            }
			
        }
    };

    this.moveSelectionMarker = function (newLocation) {
        if (newLocation !== undefined) {
            var newPoint = L.latLng(newLocation.latitude, newLocation.longitude);

            if (thisWidget.getProperty('ShowSelectionMarker') === true) {

                if (thisWidget.selectionMarker !== null) {
                    thisWidget.selectionMarker.setLatLng(newPoint);
                } else {
					var iconImg = L.icon({
					iconUrl: thisWidget.selectionMarkerStyle.image,
					iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
					});
				
                    var selMarkerOpt = {
                        icon: iconImg,
                        title: "Selection"
                    };

                    thisWidget.selectionMarker = L.marker(newPoint, selMarkerOpt);
                }
            }

            this.map.setView(newPoint);
        }
    };
    
    this.cleanupTooltipMashup = function () {
		thisWidget.map.closePopup();
    };

    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'AutoZoom') {
            setTimeout(function () {
                autofitMap();
            }, 1);
        } else {
            TW.log.error('Baidu map widget, unexpected serviceName invoked "' + serviceName + '"');
        }
    };

    this.beforeDestroy = function () {

    };

    this.cleanupRouteOverlays = function () {
        try {
            if (thisWidget.routePolyline !== undefined && this.routePolyline !== null) {
                thisWidget.map.removeLayer(thisWidget.routePolyline);
                thisWidget.routePolyline = null;
                delete this.routePolyline;
            }
        }
        catch (destroyErr) {
//        	alert('error in destroy routePolyline');
        }
    };

    this.cleanupPlannedRouteOverlays = function () {
        try {
            if (this.plannedRoutePolyline !== undefined && this.plannedRoutePolyline !== null) {
                thisWidget.map.removeLayer(thisWidget.plannedRoutePolyline);
                this.plannedRoutePolyline = null;
                delete this.plannedRoutePolyline;
            }
        }
        catch (destroyErr) {
//        	alert('error in destroy plannedRoutePolyline');
        }
    };

    this.cleanupRegionOverlays = function () {
        try {
            if (this.currentRegions !== undefined && this.currentRegions !== null) {
                for (var x = 0; x < this.currentRegions.length; x++) {
                    thisWidget.map.removeLayer(this.currentRegions[x]);
                    this.currentRegions[x] = null;
                }

                this.currentRegions = {};
            }
        }
        catch (err) {
            TW.log.error('error cleanupRegionOverlays', err);
//        	alert('error in destroy routePolyline');
        }
    };

    this.cleanupMapOverlays = function () {
		thisWidget.map.eachLayer(function (theLayer) {
			thisWidget.map.removeLayer(theLayer);
			
		});
		tileLayer.addTo(thisWidget.map);
    };

    this.clearSelectedRegions = function () {
        thisWidget.selectedRegionRows = [];
        for (var regionNo = 0; regionNo < thisWidget.currentRegions.length; regionNo++) {
            var region = thisWidget.currentRegions[regionNo];
			region.setStyle({
                fillColor: region._assignedFillColor,
				color: region._assignedStrokeColor,
                weight: region._assignedStrokeWeight
            });
            region._isSelected = false;
        }
    };

    this.getAllPoints = function(){
        var points = [];
        return points.concat(thisWidget.positionData, thisWidget.routeData, thisWidget.plannedRouteData, thisWidget.regionData, thisWidget.regionLocationData);
		//return null;
    };

    this.regionClickEventListener = function (e) {
        thisWidget.setSelectedRegion(this.rowNumber);
    };

    this.regionMouseOverEventListener = function (e) {
        var region = this;
		
        if (region.rowNumber != lastRegionNumber) {
            regionInfoWindow.setContent(region.title);
            lastRegionNumber = region.rowNumber;
        }
			regionInfoWindow.setLatLng(region._tooltipCenter);
			regionInfoWindow.openOn(thisWidget.map);
	
    };

    this.setSelectedRegion = function (selectedRow) {
        var isMultiselect = thisWidget.properties['RegionMultiSelect'];
        var selectedRegion;
        for (var regionNo = 0; regionNo < thisWidget.currentRegions.length; regionNo++) {
            var currentRegion = thisWidget.currentRegions[regionNo];
            if (currentRegion.rowNumber === selectedRow) {
                selectedRegion = currentRegion;
                break;
            }
        }

		
        if (selectedRegion !== undefined) {
            if (selectedRegion._isSelected) {
                if (isMultiselect) {
                    TW.removeElementFromArray(thisWidget.selectedRegionRows, selectedRow);
                    selectedRegion._isSelected = false;
					selectedRegion.setStyle({
						fillColor: selectedRegion._assignedFillColor,
						color: selectedRegion._assignedStrokeColor,
						weight: selectedRegion._assignedStrokeWeight
					});
                    if (!thisWidget.ignoreRegionSelectionEvent) {
                        thisWidget.updateSelection('RegionData', thisWidget.selectedRegionRows);
                    }
                }
            }
            else {
                if (!isMultiselect) {
                    thisWidget.clearSelectedRegions();
                    thisWidget.selectedRegionRows = [selectedRow];
                }
                else
                    thisWidget.selectedRegionRows.push(selectedRow);

                selectedRegion._isSelected = true;
				selectedRegion.setStyle({
						fillColor: thisWidget.selectedRegionStyle.backgroundColor,
						color: thisWidget.selectedRegionStyle.lineColor,
						weight: parseInt(thisWidget.selectedRegionStyle.lineThickness)
					});
                if (!thisWidget.ignoreRegionSelectionEvent) {
                    thisWidget.updateSelection('RegionData', thisWidget.selectedRegionRows);
                }
            }
        }
		
    };

	this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {

        if (propertyName == "Data") {
            thisWidget.ignoreSelectionEvent = true;

            thisWidget.clearSelectedMarkers();

            var nSelectedRows = selectedRowIndices.length;

            for (var selectedRowIndex = 0; selectedRowIndex < nSelectedRows;selectedRowIndex++) {
                thisWidget.setSelectedMarker(selectedRowIndices[selectedRowIndex]);
            }
            
            thisWidget.ignoreSelectionEvent = false;
        }

        if (propertyName == "RegionData") {	
            thisWidget.ignoreRegionSelectionEvent = true;

            thisWidget.clearSelectedRegions();

            var nSelectedRows = selectedRowIndices.length;

            for (var selectedRowIndex = 0; selectedRowIndex < nSelectedRows;selectedRowIndex++) {
                thisWidget.setSelectedRegion(selectedRowIndices[selectedRowIndex]);
            }
            
            thisWidget.ignoreRegionSelectionEvent = false;
        }

    };
	
    this.updateProperty = function (updatePropertyInfo) {
        if (!thisWidget.haveOpenStreetMap) { return; }

        var zoomOnDataRefresh = true;

        switch( autoZoomBehavior )  {
            case 'disable-on-user-pan-zoom':
                if( userHasPannedOrZoomedSinceAutoZoom === true ) {
                    zoomOnDataRefresh = false;
                }
                break;
            case 'only-when-autozoom-invoked':
                zoomOnDataRefresh = false;
                break;
            case 'only-initial-data':
                zoomOnDataRefresh = initialData;
                initialData = false;
                break;
            default:
                zoomOnDataRefresh = true;
        }

        if (updatePropertyInfo.TargetProperty === 'Zoom') {
            var zoom = parseInt(updatePropertyInfo.RawSinglePropertyValue);
            this.map.setZoom(zoom);
        } else if (updatePropertyInfo.TargetProperty === 'SelectedLocation') {
            var location = updatePropertyInfo.RawSinglePropertyValue;

            if (location != undefined) {
                if (location.latitude != 0 && location.longitude != 0 && location.latitude != undefined && location.longitude != undefined) {
                    this.moveSelectionMarker(location);
                    thisWidget.setProperty('SelectedLocation', location);
                }
            }

            return;
        } else if (updatePropertyInfo.TargetProperty === 'RouteData') {
            var showRoute = this.getProperty('ShowRoute');
            if (showRoute) {
				var initLatlng = []; 
                thisWidget.routeDataBounds = L.latLngBounds(initLatlng);

                var dataRows = updatePropertyInfo.ActualDataRows;

                this.cleanupRouteOverlays();

                var locationField = this.getProperty('RouteLocationField');

                var nRows = dataRows.length;
                thisWidget.routeData = [];
                for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                    var row = dataRows[rowNumber];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                        var latlng = L.latLng(thisLocation.latitude, thisLocation.longitude);
                        thisWidget.routeData.push(latlng);
                        this.routeDataBounds.extend(latlng);
                    }
                }

                if (thisWidget.routeData.length > 1) {
					var line = this.routePolyline = L.polyline(thisWidget.routeData, {
                        stroke: true,
                        weight: parseInt(thisWidget.routeStyle.lineThickness),
                        color: thisWidget.routeStyle.lineColor,
                        opacity: 1.0 });
				
                    line.addTo(thisWidget.map);
                   
                }

                if (zoomOnDataRefresh ) {
					thisWidget.map.fitBounds(L.latLngBounds(thisWidget.routeData));
                }
            }
        } else if (updatePropertyInfo.TargetProperty === 'PlannedRouteData') {
            var showRoute = this.getProperty('ShowPlannedRoute');

            if (showRoute) {
				var initLatlng = []; 
				thisWidget.plannedRouteDataBounds = L.latLngBounds(initLatlng);
				
                var dataRows = updatePropertyInfo.ActualDataRows;

                this.cleanupPlannedRouteOverlays();

                var locationField = this.getProperty('PlannedRouteLocationField');

                thisWidget.plannedRouteData = [];
                var nRows = dataRows.length;

                for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                    var row = dataRows[rowNumber];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                        var latlng = L.latLng(thisLocation.longitude, thisLocation.latitude);
                        thisWidget.plannedRouteData.push(latlng);
                        this.plannedRouteDataBounds.extend(latlng);
                    }
                }

                if (thisWidget.plannedRouteData.length > 1) {

					var line = this.plannedRoutePolyline = L.polyline(thisWidget.plannedRouteData, {
                        stroke: true,
                        weight: parseInt(thisWidget.plannedRouteStyle.lineThickness),
                        color: thisWidget.plannedRouteStyle.lineColor,
                        fillOpacity: 1.0 });
					line.addTo(thisWidget.map);
                    

                }

                if (zoomOnDataRefresh ) {
					thisWidget.map.fitBounds(L.latLngBounds(thisWidget.plannedRouteData));
                }
            }
        } else if (updatePropertyInfo.TargetProperty === 'RegionData') {
            var tooltipField1 = this.getProperty('RegionTooltipField1');
            var tooltipLabel1 = this.getProperty('RegionTooltipLabel1');
            var tooltipField2 = this.getProperty('RegionTooltipField2');
            var tooltipLabel2 = this.getProperty('RegionTooltipLabel2');
            var tooltipField3 = this.getProperty('RegionTooltipField3');
            var tooltipLabel3 = this.getProperty('RegionTooltipLabel3');
            var tooltipField4 = this.getProperty('RegionTooltipField4');
            var tooltipLabel4 = this.getProperty('RegionTooltipLabel4');
            var showRegions = this.getProperty('ShowRegions');
            var showRegionTooltips = this.getProperty('ShowRegionTooltips');

            if (showRegions) {
				var initLatlng = []; 
				thisWidget.regionDataBounds = L.latLngBounds(initLatlng);

                var dataRows = updatePropertyInfo.ActualDataRows;

                var enableRegionSelection = this.getProperty('EnableRegionSelection');

                this.cleanupRegionOverlays();

                var locationsField = this.getProperty('RegionLocationsField');
                var locationField = this.getProperty('RegionLocationField');
                var fillOpacity = this.getProperty('RegionFillOpacity');

                thisWidget.currentRegions = [];
                thisWidget.regionData = [];

                var nRows = dataRows.length;

                for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                    var row = dataRows[rowNumber];
                    var locationTable = row[locationsField];
                    if(locationTable !== undefined) {
                        var RegionLatLngList = [];
                        var regionDataRows = locationTable.rows;
                        var nRegionRows = regionDataRows.length;

						var initLatlng1 = []; 
                        var polygonBounds = L.latLngBounds(initLatlng1);

                        for (var regionRowNumber = 0; regionRowNumber < nRegionRows; regionRowNumber++) {
                            var regionRow = regionDataRows[regionRowNumber];
                            var thisLocation = regionRow[locationField];
                            if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                                var latlng = L.latLng(thisLocation.latitude, thisLocation.longitude);
                                RegionLatLngList.push(latlng);
                                thisWidget.regionData.push(latlng);
                                thisWidget.regionDataBounds.extend(latlng);
                                polygonBounds.extend(latlng);
                            }
                        }

                        if (RegionLatLngList.length > 1) {

                            var hasRegionFormatting = thisWidget.properties['RegionFormatting'] !== undefined;

                            var formatStyle = thisWidget.regionStyle;

                            if (hasRegionFormatting) {
                                formatStyle = TW.getStyleFromStateFormatting({ DataRow: row, StateFormatting: thisWidget.properties['RegionFormatting'] });
                            }

							var regionPolygon = L.polygon(RegionLatLngList, {
                                color: formatStyle.lineColor,
                                weight: parseInt(formatStyle.lineThickness),
								fillColor: formatStyle.backgroundColor,
                                opacity: fillOpacity
                            });
							regionPolygon.addTo(thisWidget.map);
							
                            regionPolygon._assignedFillColor = formatStyle.backgroundColor;
                            regionPolygon._assignedStrokeColor = formatStyle.lineColor;
                            regionPolygon._assignedStrokeWeight = parseInt(formatStyle.lineThickness);

                            regionPolygon.rowNumber = rowNumber;
                            regionPolygon.rowData = row;
                            regionPolygon._isSelected = false;
                            regionPolygon._tooltipCenter = polygonBounds.getCenter();

                            if (enableRegionSelection) {
                                regionPolygon.addEventListener('click', this.regionClickEventListener);
                            }

                            this.currentRegions.push(regionPolygon);

                            if(showRegionTooltips) {
                                var title = '';

                                if (tooltipField1 !== undefined && tooltipField1 !== '') {
                                    if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                                        title = title + tooltipLabel1 + ' : ';
                                    else
                                        title = title + tooltipField1 + ' : ';

                                    title = title + row[tooltipField1];
                                }

                                if (tooltipField2 !== undefined && tooltipField2 !== '') {
                                    if (title.length > 0)
                                        title = title + '<BR>';

                                    if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                                        title = title + tooltipLabel2 + ' : ';
                                    else
                                        title = title + tooltipField2 + ' : ';

                                    title = title + row[tooltipField2];
                                }

                                if (tooltipField3 !== undefined && tooltipField3 !== '') {
                                    if (title.length > 0)
                                        title = title + '<BR>';

                                    if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                                        title = title + tooltipLabel3 + ' : ';
                                    else
                                        title = title + tooltipField3 + ' : ';

                                    title = title + row[tooltipField3];
                                }

                                if (tooltipField4 !== undefined && tooltipField4 !== '') {
                                    if (title.length > 0)
                                        title = title + '<BR>';

                                    if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                                        title = title + tooltipLabel4 + ' : ';
                                    else
                                        title = title + tooltipField4 + ' : ';

                                    title = title + row[tooltipField4];
                                }

                                if (title.length > 0) {
                                    regionPolygon.title = title;
                                    regionPolygon.addEventListener('mouseover', this.regionMouseOverEventListener);
                                }
                            }

                        }

                    }
                }

                // Autofit if we have more than one data point

                if (zoomOnDataRefresh) {
					thisWidget.map.fitBounds(L.latLngBounds(thisWidget.regionData));
                }
            }
        } else if (updatePropertyInfo.TargetProperty === 'Data') {
            dataInfotable = {
                dataShape: {
                    fieldDefinitions: updatePropertyInfo.DataShape
                },
                rows: []
            };
			
			this.currentMarkers = [];
			var initLatlng = []; 
            this.dataBounds = L.latLngBounds(initLatlng);
            this.selectedRows = [];
            

            var dataRows = updatePropertyInfo.ActualDataRows;

            lastData = dataRows;

            this.cleanupMapOverlays();

            var locationField = this.getProperty('LocationField');
            var tooltipField1 = this.getProperty('TooltipField1');
            var tooltipLabel1 = this.getProperty('TooltipLabel1');
            var tooltipField2 = this.getProperty('TooltipField2');
            var tooltipLabel2 = this.getProperty('TooltipLabel2');
            var tooltipField3 = this.getProperty('TooltipField3');
            var tooltipLabel3 = this.getProperty('TooltipLabel3');
            var tooltipField4 = this.getProperty('TooltipField4');
            var tooltipLabel4 = this.getProperty('TooltipLabel4');
            thisWidget.positionData = [];
            var showMarkers = this.getProperty('ShowMarkers');
            var showMarkerTooltips = this.getProperty('ShowMarkerTooltips');

            if (showMarkerTooltips == null || showMarkerTooltips == undefined) {
                showMarkerTooltips = true;
            }

            var enableMarkerSelection = this.getProperty('EnableMarkerSelection');

            var nRows = dataRows.length;

            for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
				//alert("nRows=" + nRows);
				
                var row = dataRows[rowNumber];
                var thisLocation = row[locationField];
                if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                    var latlng = L.latLng(thisLocation.latitude, thisLocation.longitude);
                    thisWidget.positionData.push(latlng);

                    if (showMarkers) {

                        var markerProps = {
                            position: latlng
                        };

                        if(showMarkerTooltips) {
                            var title = '';

                            if (tooltipField1 !== undefined && tooltipField1 !== '') {
                                if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                                    title = title + tooltipLabel1 + ' : ';
                                else
                                    title = title + tooltipField1 + ' : ';

                                title = title + row[tooltipField1];
                            }

                            if (tooltipField2 !== undefined && tooltipField2 !== '') {
                                if (title.length > 0)
                                    title = title + '\n';

                                if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                                    title = title + tooltipLabel2 + ' : ';
                                else
                                    title = title + tooltipField2 + ' : ';

                                title = title + row[tooltipField2];
                            }

                            if (tooltipField3 !== undefined && tooltipField3 !== '') {
                                if (title.length > 0)
                                    title = title + '\n';

                                if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                                    title = title + tooltipLabel3 + ' : ';
                                else
                                    title = title + tooltipField3 + ' : ';

                                title = title + row[tooltipField3];
                            }

                            if (tooltipField4 !== undefined && tooltipField4 !== '') {
                                if (title.length > 0)
                                    title = title + '\n';

                                if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                                    title = title + tooltipLabel4 + ' : ';
                                else
                                    title = title + tooltipField4 + ' : ';

                                title = title + row[tooltipField4];
                            }

                            if (title.length > 0 && !isMashupTooltipConfigured) {
                                markerProps.title = title;
                            }
                        }

                        var markerField = thisWidget.properties['MarkerField'];
                        var hasFormatting = thisWidget.properties['MarkerFormatting'] !== undefined;

                        if (hasFormatting) {
                            var formatStyle = TW.getStyleFromStateFormatting({ DataRow: row, StateFormatting: thisWidget.properties['MarkerFormatting'] });
                            if (formatStyle.styleDefinitionName !== undefined) {
                                markerProps.icon = formatStyle.image;
                            } else {
                                markerProps.icon = thisWidget.markerStyle.image;
                            }
                        } else {
                            markerProps.icon = thisWidget.markerStyle.image;
                        }

                        if (markerField !== undefined && markerField !== '') {
                            var markerImagePath = row[markerField];
                            if(markerImagePath !== undefined && markerImagePath !== '') {
                                markerProps.icon = markerImagePath;
                            }
                        }
 
						var iconImg = L.icon({
							iconUrl: markerProps.icon,
							iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
						});
                        var markerOpt = {
                            icon: iconImg,
                            title: markerProps.title
                        };

                        var marker = L.marker(latlng, markerOpt);
                        marker.rowNumber = rowNumber;
                        marker.rowData = row;
                        marker._isSelected = false;
                        marker._assignedIcon = iconImg;
						marker.addTo(thisWidget.map);
						

                        this.currentMarkers.push(marker);

                        this.markerLookup.push({ latlng : latlng, marker : marker});

                        // This funky code is because we are in a loop and need to do some closure magic

                        if (isMashupTooltipConfigured) {
                            marker.addEventListener('mouseover', handleMarkerMouseover);
                        }
                        if (enableMarkerSelection) {
                            marker.addEventListener('click', handleMarkerClick);
                            marker.addEventListener('dblclick', handleMarkerDoubleClick);
                        }
					
                    }

                    this.dataBounds.extend(latlng);
                   
                }
				
            }

			
            var showPathBetweenMarkers = this.getProperty('ShowPathBetweenMarkers');
			
		   if (thisWidget.positionData.length > 1 && showPathBetweenMarkers) {
				var line = this.polyline = L.polyline(thisWidget.positionData, {
                        stroke: true,
                        weight: parseInt(thisWidget.pathStyle.lineThickness),
                        color: thisWidget.pathStyle.lineColor,
                        opacity: 1.0 });
				
                line.addTo(thisWidget.map);
					
	
                if (this.getProperty('ShowEndMarker')) {
					var iconImg = L.icon({
						iconUrl: thisWidget.endMarkerStyle.image,
						iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
					});
					var markerOpt = {
						icon: iconImg,
						title: "End"
					};
					this.endMarker = L.marker(thisWidget.positionData[thisWidget.positionData.length - 1], markerOpt);
					this.endMarker.addTo(map);
                }

                if (this.getProperty('ShowStartMarker')) {
					var iconImg = L.icon({
						iconUrl: thisWidget.startMarkerStyle.image,
						iconSize: [thisWidget.markerWidth, thisWidget.markerHeight]
					});
					var markerOpt = {
						icon: iconImg,
						title: "Start"
					};
					this.startMarker = L.marker(thisWidget.positionData[0], markerOpt);
					this.startMarker.addTo(map);
                }

            }
			

            if (zoomOnDataRefresh) {
				thisWidget.map.fitBounds(L.latLngBounds(thisWidget.positionData));
            }

            // Finally, handle any pre-selected markers
			
            thisWidget.clearSelectedMarkers();
            var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

            if (selectedRowIndices !== undefined) {
                var nSelectedRows = selectedRowIndices.length;

                for (var selectedRowIndex = 0; selectedRowIndex < nSelectedRows; selectedRowIndex++) {
                    thisWidget.setSelectedMarker(selectedRowIndices[selectedRowIndex]);
                }
            }
			
        }
    };
};
